﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;

namespace pr22._106Ovchinnikov2
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string text = txbInputText.Text.ToLower();//получение введенного текста 
                if (!IsAngl(text)) 
                {
                    MessageBox.Show("Вы ввели слова не на английском, " +
                        "или это вообще не слова\n" +
                        "Попробуйте заново");
                }
                int col = 0;
                char[] glasn = { 'a', 'o', 'e', 'i', 'u', 'y' };
                foreach (char letter in text)// нахождение количества гласных
                {
                    if (glasn.Contains(letter))
                    {
                        col++;
                    }
                }
                colLetter.Content = col.ToString();
                string[] words = text.Split(new char[] { ' ', ',', '.', ';', '-' });
                string maxLongWord = "";
                int maxLenght = 0;
                foreach (string word in words)//нахождение самого длинного слова
                {
                    if (word.Length > maxLenght)
                    {
                        maxLenght = word.Length;
                        maxLongWord = word;
                    }
                }
                longWord.Content = maxLongWord.ToString();
            } 
            catch (Exception ex)
            { 
                MessageBox.Show("Произошла ошибка: " + ex.Message + "попробуйте заново");
            }
        }
        private bool IsAngl(string str) //проверка на введение английских слов
        {
            return Regex.IsMatch(str, @"^[a-zA-Z\s]");
        }
    }
}
